<?php
// 👩‍💻 Incluez le header
include('header.php');
include('functions.php');
include('db.php');
?>

<h1>Hello there!</h1>

<p>Bienvenue sur mon super site de recettes, on va s'en mettre plein la panse!</p>

<img src="https://st.depositphotos.com/1570716/1697/i/950/depositphotos_16978587-stock-photo-male-chef-cooking.jpg" alt="">

<div>
    <a href="recipes.php">Par ici les recettes!</a>
</div>

<?php
// 👩‍💻 Incluez le footer
include('footer.php');
?>
