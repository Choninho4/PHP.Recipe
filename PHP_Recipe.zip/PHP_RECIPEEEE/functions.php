<?php
// Inclure le fichier 'recipe.php' s'il est nécessaire
include('recipe.php');
include('db.php');

// Fonction pour générer un ID unique
function generateUniqueID() {
    return mt_rand(1, 1000);
}

// Fonction pour sauvegarder une recette dans un fichier JSON
function saveRecipe($recipeDetails) {
    // Générer un ID unique pour la recette
    $recipeDetails['id'] = generateUniqueID();

    // Construire le chemin du fichier en utilisant l'ID de la recette
    $filePath = 'data/recettes/' . $recipeDetails['id'] . '.json';

    // Convertir les détails de la recette en format JSON
    $jsonRecipe = json_encode($recipeDetails, JSON_PRETTY_PRINT);

    // Sauvegarder le fichier JSON
    file_put_contents($filePath, $jsonRecipe);

    // Retourner l'ID de la recette généré
    return $recipeDetails['id'];
}

// Fonction pour lire toutes les recettes depuis un dossier spécifié
function lireToutesLesRecettes($dossier) {
    // Vérifier si le dossier existe
    if (!is_dir($dossier)) {
        // Gérer l'erreur, par exemple en lançant une exception
        throw new Exception("Le dossier des recettes n'existe pas.");
    }

    // Initialiser le tableau qui contiendra les recettes
    $recettes = array();

    // Ouvrir le dossier
    $handle = opendir($dossier);

    // Parcourir les fichiers du dossier
    while (false !== ($fichier = readdir($handle))) {
        // Exclure les fichiers spéciaux (., .., etc.)
        if ($fichier != "." && $fichier != "..") {
            // Lire le contenu du fichier
            $cheminFichier = $dossier . '/' . $fichier;
            $contenuRecette = file_get_contents($cheminFichier);

            // Ajouter la recette au tableau
            $recettes[] = json_decode($contenuRecette, true);
        }
    }

    // Fermer le gestionnaire de dossier
    closedir($handle);

    // Retourner le tableau de recettes
    return $recettes;
}

// Fonction pour récupérer toutes les recettes depuis les fichiers JSON
function getAllRecipes() {
    // Déclarer la variable $recipes comme un tableau vide pour stocker les données des recettes.
    $recipes = array();

    // Utiliser la fonction `glob()` pour récupérer les noms de tous les fichiers JSON de recettes dans le dossier 'data/recettes/'.
    $recipeFiles = glob('data/recettes/*.json');

    // Itérer à travers chaque fichier de recettes récupéré par `glob()`.
    foreach ($recipeFiles as $file) {
        // Lire le contenu du fichier JSON actuel (file_get_contents).
        $content = file_get_contents($file);

        // Décoder le contenu JSON en un tableau PHP (json_decode) et l'ajouter au tableau $recipes.
        $recipeData = json_decode($content, true);
        $recipes[] = $recipeData;
    }

    // Retourner le tableau $recipes contenant toutes les recettes.
    return $recipes;
}

// Fonction pour récupérer une recette spécifique par son ID
function getRecipe($id) {
    // Définir une variable contenant le chemin du fichier en concaténant le chemin du dossier, l'ID de la recette, et l'extension '.json'.
    $cheminFichier = 'data/recettes/' . $id . '.json';

    // Récupérer le contenu du fichier (si le fichier spécifié existe).
    if (file_exists($cheminFichier)) {
        // Lire le contenu du fichier JSON actuel (file_get_contents).
        $content = file_get_contents($cheminFichier);

        // Décoder le contenu JSON en un tableau PHP (json_decode) et le retourner.
        return json_decode($content, true);
    } else {
        // Si le fichier n'existe pas, retourner null.
        return null;
    }
}
?>
