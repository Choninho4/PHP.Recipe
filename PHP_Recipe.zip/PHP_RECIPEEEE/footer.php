</main>
<footer>
    <p>&copy; <?php echo date("Y"); ?> Mon Site de Recettes. Tous droits réservés.</p>

    <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">Ne pas cliquer ici.</a>
</footer>
</body>
</html>
